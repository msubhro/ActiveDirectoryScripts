
<# Welcome to PowerDNS V1.0! This Script is prepared by Subhro Majumder.#>

<# The script has been prepared and tested in Powershell 4.0. So when you run this script, please make sure that the Powershell version is 4.0 or above. #>

<# Using this script , you can LookUp, Create and Delete A,PTR and CNAME Records.#>

<# This script is suitable for single record entry as well as bulk entry. For every operation there are two options, Single and Bulk. 

For Bulk entry you need to cretae an input file in CSV format. Sample input files has been provided along with this script. #>

<# While Deleting records, you will get a confirmation box for each record, to ensure that you are going to delete the correct record. #>

<# While this script has been tested multiple times, I recommend that you test it in a test environment before using it in a production environment.#>

<# While every attempt has been made to make this script error free, I will not take any responsibilty for any consequence that would happen while running the script.#>


function Show-Menu

{


     param (
           [string]$Title = 'Welcome to the PowerDNS V1.0 ! This is a one stop solution for all DNS related work'
     )
     cls
     Write-Host "=====$Title ====="
     Write-Host "                   "
     
     Write-Host "Using this script , you can LookUp, Create and Delete A,PTR and CNAME Records."
     Write-Host "                   "
     Write-Host "The script has been prepared and tested in Powershell 4.0. So when you run this script, please make sure that the Powershell version is 4.0 or above."
     Write-Host "                   "
     Write-Host "This script is suitable for single record entry as well as bulk entry. For every operation there are two options, Single and Bulk."
     Write-Host "                   "
     Write-Host "For Bulk entry you need to cretae an input file in CSV format. Sample input files has been provided along with this script."
     Write-Host "                   "
     Write-Host "While Deleting records, you will get a confirmation box for each record, to ensure that you are going to delete the correct record."
     Write-Host "                   "
     Write-Host "While this script has been tested multiple times, I recommend that you test it in a test environment before using it in a production environment."
     Write-Host "                   "
     Write-Host "While every attempt has been made to make this script error free, I will not take any responsibilty for any consequence that would happen while running the script."

     Write-Host "                   "

     Write-Host "--------------MENU----------------"
     Write-Host "                   "
     Write-Host "1: Press 1 to Lookup DNS Records."
     Write-Host "                   "
     Write-Host "2: Press 2 to Create Host Records."
     Write-Host "                   "
     Write-Host "3: Press 3 to Create PTR Records."
     Write-Host "                   "
     Write-Host "4: Press 4 to Create CNAME Records."
     Write-Host "                   "
     Write-Host "5: Press 5 to Delete Host Records."
     Write-Host "                   "
     Write-Host "6: Press 6 to Delete PTR Records."
     Write-Host "                   "
     Write-Host "7: Press 7 to Delete CNAME Records."
     Write-Host "                   "
     Write-Host "Q: Press 'Q' to quit this Program."
     Write-Host "----------------------------------"
     Write-Host "                   "

}

function Lookup-SingleDNS

{

cls
'You chose Single DNS Lookup'
$input = Read-Host "Please enter the value you want to look up"

Resolve-DNSName -Name "$input" -nohostsfile -type All | ft Name,Type,TTL,IPAddress,Namehost -autosize
"                       "
"                        "
 
} 

function Lookup-BulkDNS

{

cls
'You chose Bulk DNS Lookup'

$inputfile = Read-Host "Please enter the location of the input file"
$output1= Read-Host "Please enter the location of the output file"

$records= Get-Content $inputfile
 
foreach ($record in $records)
{
 
$output=Resolve-DnsName -Name $record -NoHostsFile -Type ALL
$output | ft Name,Type,IPAddress,NameHost | Out-File -FilePath $output1 -Append -NoClobber
 
 
}

}


function Create-SingleHostEntry

{

Write-Host "Please Note: While creating the Host Record, corresponding PTR Record will also be created."

$dnsserver= Read-Host "Please enter the DNS Server Name where you want to create the Record"
$zone= Read-Host "Please enter the Zone Name"
$name= Read-Host "Please enter the Record value (Without FQDN )"
$IP= Read-Host "Please enter the IP Address"

Add-DnsServerResourceRecordA -ComputerName $dnsserver -Name $name -ZoneName $zone -IPv4Address $IP -TimeToLive 05:00:00 -CreatePtr -Confirm


}

function Create-BulkHostEntry

{

Write-Host "Please Note: While creating the Host Records, corresponding PTR Records will also be created."

$dnsserver= Read-Host "Please enter the DNS Server Name where you want to create the Record"
$zone= Read-Host "Please enter the Zone Name"

$inputfile = Read-Host "Please enter the location of the input file. Input file format is CSV. Include these headers: name,IP"

import-csv -Path $inputfile| foreach-object {Add-DnsServerResourceRecordA -computername $dnsserver -Name $_.name -ZoneName $zone -IPv4Address $_.IP -TimeToLive 05:00:00 -CreatePtr -Confirm}


}


function Create-SinglePTREntry

{

$dnsserver= Read-Host "Please enter the DNS Server Name where you want to create the Record"
$zone= Read-Host "Please enter the Reverse Zone Name"
$FQDN= Read-Host "Please enter the record value (With FQDN )"
$IP= Read-Host "Please enter the Host octects of the IP Address.Please do not include Network octets."

Add-DnsServerResourceRecord -ComputerName $dnsserver -Name $IP -PTR -ZoneName $zone -PtrDomainName $FQDN -TimeToLive 05:00:00 -Confirm

}

function Create-BulkPTREntry

{

$dnsserver= Read-Host "Please enter the DNS Server Name where you want to create the Record"
$zone= Read-Host "Please enter the Reverse Zone Name"

$inputfile = Read-Host "Please enter the location of the input file. Input file format is CSV. Include these headers: IP,FQDN"

Import-Csv -Path $inputfile| foreach-object { Add-DnsServerResourceRecord -ComputerName $dnsserver -Name $_.IP -PTR -ZoneName $zone -PtrDomainName $_.FQDN -TimeToLive 05:00:00 -Confirm}

}


function Create-SingleCNAMEEntry


{

$dnsserver= Read-Host "Please enter the DNS Server Name where you want to create the Record"
$alias= Read-Host "Please enter the Alias Name"
$zonename= Read-Host "Please enter the Zone Name"
$FQDN= Read-Host "Please enter the FQDN for the alias"


Add-DnsServerResourceRecord -CName -ComputerName $dnsserver -Name $alias -HostNameAlias $FQDN -ZoneName $zonename -TimeToLive 05:00:00 -Confirm

}


function Create-BulkCNAMEEntry

{

$dnsserver= Read-Host "Please enter the DNS Server Name where you want to create the Record"
$zonename= Read-Host "Please enter the Zone Name"

$inputfile = Read-Host "Please enter the location of the input file. Input file format is CSV: alias,FQDN."

Import-Csv -Path $inputfile| foreach-object { Add-DnsServerResourceRecord -CName -ComputerName $dnsserver -Name $_.alias -HostNameAlias $_.FQDN -ZoneName $zonename -TimeToLive 05:00:00 -Confirm
 }

 
}


function Delete-SingleHostEntry

{

Write-Host "There can be multiple Host Records (IPs) for a given Host Name. Only one Record for the matching IP address will be deleted"
Write-Host "For Example: In contoso.com zone there are two records test.contoso.com > 192.168.1.23 and 
test.contoso.com > 192.168.1.24. This action removes only one of the entries of test.contoso.com, matching the IP address."

$dnsserver= Read-Host "Please enter the DNS Server Name from where you want to delete the Record"
$zonename= Read-Host "Please enter the Zone Name"
$name= Read-Host "Please enter the Host Record Name (Without FQDN)"
$IP= Read-Host "Please enter the IP address of the Host Record which you want to delete"


Remove-DnsServerResourceRecord -computername $dnsserver -ZoneName $zonename -RRType "A" -Name $name -RecordData $IP -Confirm


}

function Delete-BulkHostEntry

{
Write-Host "There can be multiple Host Records (IPs) for a given Host Name. Only one Record for the matching IP address will be deleted"
Write-Host "For Example: In contoso.com zone there are two records test.contoso.com > 192.168.1.23 and test.contoso.com > 192.168.1.24. This action removes only one of the entries of host.contoso.com, matching the IP address."

Write-Host "                  "

$dnsserver= Read-Host "Please enter the DNS Server Name from where you want to delete the record"
$zonename= Read-Host "Please enter the Zone Name where the Record is located"

$inputfile = Read-Host "Please enter the location of the input file. Input file format is CSV.Please include these Headers: name,IP."


Import-Csv -Path $inputfile| foreach-object { Remove-DnsServerResourceRecord -computername $dnsserver -ZoneName $zonename -RRType "A" -Name $_.name -RecordData $_.IP -Confirm}


}


function Delete-SinglePTREntry

{

$dnsserver= Read-Host "Please enter the DNS Server Name from where you want to delete the record"
$zonename= Read-Host "Please enter the Reverse Zone Name"
$IP= Read-Host "Please enter the IP address of the PTR Record. Only the Host octet is required."


Remove-DnsServerResourceRecord -computername $dnsserver -ZoneName $zonename -RRType "PTR" -Name $IP -Confirm

}


function Delete-BulkPTREntry

{

$dnsserver= Read-Host "Please enter the DNS Server Name from where you want to delete the record"
$zonename= Read-Host "Please enter the Reverse Zone Name"

$inputfile = Read-Host "Please enter the location of the input file. Input file format is CSV.Include the Header: IP."


Import-Csv -Path $inputfile| foreach-object {Remove-DnsServerResourceRecord -computername $dnsserver -ZoneName $zonename -RRType "PTR" -Name $_.IP -Confirm}

}


function Delete-SingleCNAMEEntry


{

$dnsserver= Read-Host "Please enter the DNS Server Name from where you want to delete the record"
$zonename= Read-Host "Please enter the Zone Name where the Alias Record is located."
$name= Read-Host "Please enter the Alias Name (Without FQDN)"


Remove-DnsServerResourceRecord -computername $dnsserver -ZoneName $zonename -RRType "CNAME" -Name $name -Confirm


}


function Delete-BulkCNAMEEntry


{

$dnsserver= Read-Host "Please enter the DNS Server Name from where you want to delete the record"

$zonename= Read-Host "Please enter the Zone Name where the Alias Record is located."

$inputfile = Read-Host "Please enter the location of the input file. Input file format is CSV. Include the Header: aliasname."


Import-Csv -Path $inputfile| foreach-object {Remove-DnsServerResourceRecord -computername $dnsserver -ZoneName $zonename -RRType "CNAME" -Name $_.alias -Confirm}


}

do
{
     Show-Menu
     $input = Read-Host "Please make a selection"
     switch ($input)
     {
           '1' {
                cls
                'You have selected option #1'
                'Press 1 for Single DNS Lookup'
                'Press 2 for Bulk DNS Lookup'
                'Press Q to Return to the Main Menu'
                $input1=Read-Host "Please make a selection"
                switch ($input1)

                {

                  1 { Lookup-SingleDNS }

                  2 { Lookup-BulkDNS}

                  Q { Show-Menu} 

                }

                  } 
           
           '2' {
                cls
                'You have selected option #2'

                'Press 1 for Single Host Entry'
                'Press 2 for Bulk Host Entries'
                'Press Q to Return to the Main Menu'

                $input1=Read-Host "Please make a selection"

                 switch ($input1)

                {

                  1 { Create-SingleHostEntry }

                  2 { Create-BulkHostEntry}

                  Q { Show-Menu } 

                }

                  }
           
           
           
           '3'  {
                cls
                'You have selected option #3'

                'Press 1 for Single PTR Record'
                'Press 2 for Bulk PTR Records'
                'Press Q to Return to the Main Menu'

                $input1=Read-Host "Please make a selection"

                 switch ($input1)

                {

                  1 { Create-SinglePTREntry }

                  2 { Create-BulkPTREntry}

                  Q { Show-Menu} 

                }

                  }


               '4'  {

                cls

                'You have selected option #4'

                'Press 1 for Single CNAME Record'
                'Press 2 for Bulk CNAME Records'
                'Press Q to Return to the Main Menu'

                $input1=Read-Host "Please make a selection"

                 switch ($input1)

                {

                  1 { Create-SingleCNAMEEntry }

                  2 { Create-BulkCNAMEEntry}

                  Q { Show-Menu } 

                }

                  }



                     '5'  {

                cls

                'You have selected option #5'

                'Press 1 to Delete Single Host Record'
                'Press 2 to Delete multiple Host Records '
                'Press Q to Return to the Main Menu'

                $input1=Read-Host "Please make a selection"

                 switch ($input1)

                {

                  1 { Delete-SingleHostEntry }

                  2 { Delete-BulkHostEntry}

                  Q { Show-Menu } 

                }

                  }



                  '6'  {

                cls

                'You have selected option #6'

                'Press 1 to Delete Single PTR Record'
                'Press 2 to Delete multiple PTR Records '
                'Press Q to Return to the Main Menu'

                $input1=Read-Host "Please make a selection"

                 switch ($input1)

                {

                  1 { Delete-SinglePTREntry }

                  2 { Delete-BulkPTREntry}

                  Q { Show-Menu} 

                }

                  }




                  '7'  {

                cls

                'You have selected option #7'

                'Press 1 to Delete Single CNAME Record'
                'Press 2 to Delete multiple CNAME Records '
                'Press Q to Return to the Main Menu'

                $input1=Read-Host "Please make a selection"

                 switch ($input1)

                {

                  1 { Delete-SingleCNAMEEntry }

                  2 { Delete-BulkCNAMEEntry}

                  Q { Show-Menu } 

                }

                  }


          
           'q' {
                return
               }
     }
     pause
}
until ($input -eq 'q')