﻿########### Beginnning of Main Menu #########

function Show-Menu

{


     param (
           [string]$Title = 'Welcome to the PowerGroup V1.0 !'
     )
     cls
     Write-Host "=====$Title ====="
     Write-Host "                   "
     
     Write-Host "Using this script , you can get member of groups,User's group membership,Mirror Group membership,Append Group Membership."
     Write-Host "                   "
     Write-Host "You can also add multiple users in multiple groups, based on a single input file.The input file format is provided with the script."
     Write-Host "   "
     Write-Host "The script has been prepared and tested in Powershell 4.0. So when you run this script, please make sure that the Powershell version is 4.0 or above."
     Write-Host "                   "
     Write-Host "Test before you use in production."
     Write-Host "                   "
     Write-Host "Use at your own Risk."

     Write-Host "                   "

     Write-Host "--------------MENU----------------"
     Write-Host "                   "
     Write-Host "1: Press 1 to get members of multiple groups."
     Write-Host "                   "
     Write-Host "2: Press 2 to Append Group Membership, based on another Group."
     Write-Host "                   "
     Write-Host "3: Press 3 to Mirror Group Membership."
     Write-Host "                   "
     Write-Host "4: Press 4 to add multiple users in multiple groups."
     Write-Host "                   "
     Write-Host "Q: Press Q to quit this Program."
     Write-Host "----------------------------------"
     Write-Host "                   "

}


########### End of Main Menu #########

########### Beginnning of the function Group Members #########

function GroupMembers

{

write-host "   "

write-host "This program will generate the list of all members of a group, including nested members."

write-host "   "

Write-Warning " For nested groups, it will not show the nested group name, but it will capture members of all the nested groups."

write-host "   "

$inputpath= Read-Host "Enter the Name of the input file. It should be a text file containing group name."

write-host "   "

$outputpath= Read-Host "Enter the Name of the output file. It should be a CSV file."

write-host "   "

$server= Read-Host "Enter the Name a Global catalog server, in the same forest where groups are present. Please provide FQDN."


write-host "   "

$grouplist=get-content -Path $inputpath

foreach ($group in $grouplist)

{


$member= get-adgroup  $group -Server $server | Get-ADGroupMember -Recursive | Get-ADObject -Properties * | select-object @{label='Group Name';expression={$group}},@{label='Member Name';expression={$_.sAMAccountName}},@{label='Member Type';expression={$_.ObjectClass}},CanonicalName

$member

$member| export-csv -Path $outputpath -NoTypeInformation -Append

}

}

########### End of the function Group Members #########


########### Beginning of the function Append Group Membership #########

function GroupAppend

{

Write-Host "    "

$user1 = Read-Host "Enter the Name of the user/group, who's membership you want to Append. The user/computer account must be from the current domain."

Write-Host "    "

$user2 = Read-Host "Enter the Name of the user/group, where you want the group membership to be appended. The user/computer account must be from the current domain."

Write-Host "    "

Write-Warning "The existing group membership of this user/computer/group account will remain unchnaged, and the new groups would be appended on the top of it."

Write-Host "    "

$grouplist= (Get-ADPrincipalGroupMembership -Identity $user1).name

Foreach ($group in $grouplist)
{

Add-ADGroupMember -Identity $group -Members $user2

}

}


########### End of the function Append Group Membership #########

########### Beginning of the function Mirror Group Membership #########

function GroupMirror

{

Write-Host "    "

Write-Warning "The existing group membership of this User/Group will be removed, and only the new groups would be added."

Write-Host "    "

$user1 = Read-Host "Enter the Name of the User/Group, who's membership you want to be Mirrorred. The User/Group must be from the current domain."

Write-Host "    "

$user2 = Read-Host "Enter the Name of the User/Group, where you want the group membership to be Mirrorred. The User/Group must be from the current domain."

Write-Host "    "

Get-ADPrincipalGroupMembership -Identity $user2 | % {Remove-ADPrincipalGroupMembership -Identity $user2 -MemberOf $_}

$grouplist = (Get-ADPrincipalGroupMembership -Identity $user1).Name


Foreach ($group in $grouplist)
{

Add-ADGroupMember -Identity $group -Members $user2

}

}

########### End of the function Mirror Group Membership #########

########### Beginning of the function Multiple Users in Multiple Groups #########

function MultiUsersMultiGroups

{

write-host "      "

$inputfile = Read-Host "Please enter the location of the input file. Input file format is CSV. Please refer the format in the sample file."

write-host "      "

$inputlist=Import-Csv $inputfile


ForEach ($input in $inputlist)

{

$group= $input.GroupName

$memberlist= $input.members -split ","

foreach ($member in $memberlist)

{

Add-ADGroupMember $group $member


}

}

}




########### End of the function Multiple Users in Multiple Groups #########



########### Beginnning of Sub Menus and Function Execution #########

do
{
     Show-Menu
     $input = Read-Host "Please make a selection"
     switch ($input)
     {
           '1' {
                cls
                'You have selected option #1: Get Group Membership.'
                 Write-host "               "
                 GroupMembers

                  } 
           
           '2' {
                cls
                'You have selected option #2: Append Group Members based on a Reference Group.'
                 
                 Write-host "               "
                 
                 GroupAppend
                }
           
           
           
           '3'  {
                cls
                'You have selected option #3: Mirror Group Members based on a Reference Group.'
                                
                 Write-host "               "
                 
                 GroupMirror

                }

'4'  {
                cls
                'You have selected option #4: Add Multiple Users to Multiple Groups.'
                                
                 Write-host "               "
                 
                 MultiUsersMultiGroups

                }
 
           

          
           'q' {
                return
               }
     }
     pause
}
until ($input -eq 'q')


########### End of Sub Menus and Function Execution #########